//
//  LoginFormController.swift
//  homeworkVK
//
//  Created by DNS on 09/05/2022.
//

import UIKit

class LoginFormController: UIViewController {
    @IBOutlet weak var scroll: UIScrollView!
    @IBOutlet weak var logo: UIImageView!
    
    @IBOutlet weak var password: UILabel!
    @IBOutlet weak var login: UILabel!
    @IBAction func nextElement(_ sender: Any) {
    }
    
    @objc func keyboardWasShown(notification: Notification) {
        let info = notification.userInfo! as NSDictionary
        let kbSize = (info.value(forKey: UIResponder.keyboardFrameEndUserInfoKey) as! NSValue).cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: kbSize.height, right: 0.0)
        self.scroll?.contentInset = contentInsets
        scroll?.scrollIndicatorInsets = contentInsets }
    
    @objc func keyboardWillBeHidden(notification: Notification) {}
    override func viewWillAppear(_ animated: Bool) { super.viewWillAppear(animated)
    NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWasShown), name: UIResponder.keyboardWillShowNotification, object: nil)
    
    NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) { super.viewWillDisappear(animated)
    NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
    NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func hideKeyboard() { self.scroll?.endEditing(true)
    }
    override func viewDidLoad() { super.viewDidLoad()
    let hideKeyboardGesture = UITapGestureRecognizer(target: self, action: #selector(hideKeyboard))
        scroll?.addGestureRecognizer(hideKeyboardGesture) }
    @IBAction func login(_ sender: Any) {
    let login = login.text!
    let password = password.text!
    if login == "admin" && password == "123456" { print("all OK")
    } else {
    print("Try again")
    } }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

